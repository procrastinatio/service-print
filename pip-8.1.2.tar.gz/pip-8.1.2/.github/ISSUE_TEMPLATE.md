* Pip version:
* Python version:
* Operating System:

### Description:

// REPLACE ME: What are you trying to get done, what has happened, what went wrong, and what did you expect?

### What I've run:

```
// REPLACE ME: Paste a log of command(s) you ran and pip's output, tracebacks, etc, here
```
